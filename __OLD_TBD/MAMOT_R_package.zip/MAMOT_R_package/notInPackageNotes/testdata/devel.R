
rm(list=ls())

setwd('H:/PMT3/MAMOT_R_package/notInPackageNotes/testdata');list.files()


require(geodata)
dir.create("temp")
world = geodata::world(path = "temp/")
population = geodata::population(path = "temp", year = 2020)
plot(world)
plot(population)

require(maps)
map('world')
map('lakes', add=TRUE, fill=TRUE, col="blue", boundary='black')

install.packages("spatstat")
install.packages("spdep")

require(maptools)

install.packages("GISTools")

install.packages("rnaturalearth")
install.packages("rnaturalearthdata")
require(rnaturalearth)
plot(rnaturalearth::ne_coastline())

install.packages("landscapemetrics")
help(package="landscapemetrics")

install.packages("leaflet")

install.packages("ggmap")

install.packages("ggplot")
install.packages("ggplot2")
install.packages("ggspatial")

install.packages("cartography")

require(rgrass)

require(tmap)
tmap_mode("view")
data("World")
data("metro")
tm_shape(World) +
  tm_polygons("HPI")

tmap_mode("view")
tm_basemap("Stamen.Watercolor") +
  tm_shape(metro) + tm_bubbles(size = "pop2020", col = "red") +
  tm_tiles("Stamen.TonerLabels")

install.packages("stars")

install.packages("mapview")

install.packages("rgeos")


require(s2)
??s2

?s2::s2_project()
?s2::s2_projection_orthographic()
?s2::s2_projection_plate_carree()

list.files()
lidar = stars::read_stars("lidar.tif")

getwd()
file.path("H:","GIS")
file.path(getwd(),"temp")
list.files()
plot(lidar)

################################################################################
wd = file.path("H:","PMT3","MAMOT_R_Package","notInPackageNotes","testdata")
setwd(wd); list.files()

lidar = stars::read_stars("lidar.tif")
stars::st_raster_type(lidar)
stars::st_res(lidar)

install.packages("topmodel")
topmodel::sinkfill(lidar)
help(package = topmodel)
require(topmodel)
data(huagrahuma.dem)
class(huagrahuma.dem)
as.matrix(lidar)
lidar = terra::rast("lidar.tif")

filled = topmodel::sinkfill(as.matrix(lidar), res=50, degree=0.1)

require(rgrass)
rgrass::read_RAST("lidar.tif")

install.packages("gdalUtilities")
require(gdalUtilities)
?gdalUtilities::gdaldem()

help(package=rgeos)
help(package=terra)

lidar = terra::rast("lidar.tif")
fem = terra::as.points(lidar)
terra::plot(lidar)
profile = terra::vect("profile.gpkg")
terraceMap = terra::vect("terraceMap.gpkg")
terra::lines(profile)

require(stars)
lidar = stars::read_stars(.x = "lidar.tif")
profile = stars::read_stars(.x = "profile.gpkg")

help(package=stars)

data(World)
tm_shape(lidar) + tm_raster()
tm_shape(terraceMap) + tm_polygons()



lidar = terra::rast("lidar.tif")
terra::resample(lidar)
terra::res(lidar)

fem = terra::as.points(lidar)




?resample

st_as_sf(fem)



require(terra)

bb = c(580389,603789,5299427,5381227)
ex = bb



# function that creates a raster with same or slightly larger extent than a given raster, but with a new desired resolution
# the extent may be enlarged omnidirectionally, so that the exact desired resolution fits in
# depends on package terra
# x = input raster
# rN = new resolution
pmf_alignRas = function(x,rN){
ex = terra::ext(x) # get extent of input raster
# get length of input raster dimensions
xL = ex[2]-ex[1]
yL = ex[4]-ex[3]
# calculate number, that needs to be added or subtracted to original raster xmin,xmax,ymin,ymax, so that new res fits in exactly
pmx = ( 1 - ( xL/rN - floor(xL/rN) ) ) * rN / 2
pmy = ( 1 - ( yL/rN - floor(yL/rN) ) ) * rN / 2
# calculate extent of new raster
exN = c( ex[1]-pmx, ex[2]+pmx, ex[3]-pmy, ex[4]+pmy )
# create new raster with same crs as input raster
s <- terra::rast(nrows=(exN[4]-exN[3])/rN, 
                 ncols=(exN[2]-exN[1])/rN, 
                 xmin=exN[1], xmax=exN[2], ymin=exN[3], ymax=exN[4])
values(s) = 1:ncell(s)
terra::crs(s) <- terra::crs(x)
# output
return(s)
}

s = pmf_aligneRas(lidar,1000)
plot(s); s

x <- terra::resample(lidar, s, method="cubic", threads=TRUE)

terra::plot(x)
terra::res(x)
terra::crs(x)







