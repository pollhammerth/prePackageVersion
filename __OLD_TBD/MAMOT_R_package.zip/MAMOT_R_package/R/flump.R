#' Dummy function
#'
#' Promt some shit and return the input provided
#' @param x Any object or numeric or character or whatever
#' @return The very object, that is provided to the function
#' @examples 
#' temp1 <- flump(50);
#' temp2 <- flump( c(50, 63, 23) );
#' @export
flump = function(x){
  cat("what the **** do you want me to do with that?\n")
  cat("what is that anyway? take it back!\n")
  return(x)
}